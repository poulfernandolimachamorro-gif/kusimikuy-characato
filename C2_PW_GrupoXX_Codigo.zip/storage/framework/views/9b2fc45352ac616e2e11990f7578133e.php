<?php $__env->startSection('title', 'Recetas'); ?>
<?php $__env->startSection('content'); ?>
<div class="caja-cristal" style="padding: 2rem;">
    <div style="display: flex; justify-content: space-between; margin-bottom: 1.5rem;">
        <h2 style="color: white;">Menús y Recetas</h2>
        <a href="<?php echo e(route('menus.create')); ?>" class="btn-premium" style="width: auto;">+ Nueva Receta</a>
    </div>
    <?php if(session('success')): ?> <div class="alerta-exito"><?php echo e(session('success')); ?></div> <?php endif; ?>
    <table style="width: 100%; color: #cbd5e1;">
        <thead><tr style="border-bottom: 1px solid #333;"><th>Plato</th><th>Insumo ID</th><th>Gramos/Ración</th><th>Acciones</th></tr></thead>
        <tbody>
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="border-bottom: 1px solid #222;">
                <td><?php echo e($menu->nombre_plato); ?></td>
                <td><?php echo e($menu->insumo_id); ?></td>
                <td><?php echo e($menu->gramos_por_racion); ?> g</td>
                <td>
                    <form action="<?php echo e(route('menus.destroy', $menu->id)); ?>" method="POST"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn-premium" style="background:#ef4444; width:auto; min-height:30px; padding:0 0.5rem;" onclick="return confirm('¿Eliminar?')"><i class="fa-solid fa-trash"></i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/kusimikuy-characato/resources/views/menus/index.blade.php ENDPATH**/ ?>