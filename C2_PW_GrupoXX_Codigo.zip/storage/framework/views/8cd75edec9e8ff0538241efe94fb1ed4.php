<?php $__env->startSection('title', 'Nueva Receta'); ?>
<?php $__env->startSection('content'); ?>
<div class="caja-cristal" style="max-width: 600px; margin: 0 auto; padding: 2rem;">
    <h2 style="color: white;">Registrar Receta</h2>
    <form action="<?php echo e(route('menus.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label style="color: #cbd5e1;">Nombre del Plato:</label>
        <input type="text" name="nombre_plato" class="input-asistencia-premium" required>
        <label style="color: #cbd5e1; margin-top: 1rem; display: block;">Insumo:</label>
        <select name="insumo_id" class="input-asistencia-premium">
            <?php $__currentLoopData = $insumos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insumo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($insumo->id); ?>"><?php echo e($insumo->nombre_insumo); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label style="color: #cbd5e1; margin-top: 1rem; display: block;">Gramos por Ración:</label>
        <input type="number" step="0.01" name="gramos_por_racion" class="input-asistencia-premium" required>
        <button type="submit" class="btn-premium" style="margin-top: 1.5rem;">Guardar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/kusimikuy-characato/resources/views/menus/create.blade.php ENDPATH**/ ?>