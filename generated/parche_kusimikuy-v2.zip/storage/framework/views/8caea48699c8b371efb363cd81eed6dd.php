<?php $__env->startSection('title', 'Nuevo Documento'); ?>
<?php $__env->startSection('content'); ?>
<div class="caja-cristal" style="max-width: 600px; margin: 0 auto; padding: 2rem;">
    <h2 style="color: white;">Registrar Documento</h2>
    <form action="<?php echo e(route('documentos.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label style="color: #cbd5e1;">Tipo de Documento:</label>
        <select name="tipo_documento" class="input-asistencia-premium">
            <option value="Resolución Municipal">Resolución Municipal</option>
            <option value="Registros Públicos">Registros Públicos</option>
            <option value="Libro de Actas Mensual">Libro de Actas Mensual</option>
        </select>
        <label style="color: #cbd5e1; margin-top: 1rem; display: block;">Fecha Emisión:</label>
        <input type="date" name="fecha_emision" class="input-asistencia-premium" required>
        <label style="color: #cbd5e1; margin-top: 1rem; display: block;">Fecha Caducidad:</label>
        <input type="date" name="fecha_caducidad" class="input-asistencia-premium" required>
        <button type="submit" class="btn-premium" style="margin-top: 1.5rem;">Guardar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/kusimikuy-characato/resources/views/documentos/create.blade.php ENDPATH**/ ?>