<?php $__env->startSection('title', 'Insumos'); ?>
<?php $__env->startSection('content'); ?>
<div class="caja-cristal">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
        <h2 style="color: white;">Gestión de Insumos</h2>
        <a href="<?php echo e(route('insumos.create')); ?>" class="btn-premium" style="width: auto;">+ Nuevo Insumo</a>
    </div>
    <?php if(session('success')): ?> <div class="alerta-exito"><?php echo e(session('success')); ?></div> <?php endif; ?>
    <table style="width: 100%; border-collapse: collapse; color: #cbd5e1;">
        <thead>
            <tr style="border-bottom: 2px solid rgba(255,255,255,0.1);">
                <th style="padding: 1rem;">Insumo</th>
                <th style="padding: 1rem;">Stock Actual</th>
                <th style="padding: 1rem;">Unidad</th>
                <th style="padding: 1rem;">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $insumos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insumo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                <td style="padding: 1rem;"><?php echo e($insumo->nombre_insumo); ?></td>
                <td style="padding: 1rem;"><?php echo e($insumo->stock_actual); ?></td>
                <td style="padding: 1rem;"><?php echo e($insumo->unidad_medida); ?></td>
                <td style="padding: 1rem;">
                    <div style="display: flex; gap: 0.5rem; align-items: center;">
                    <a href="<?php echo e(route('insumos.edit', $insumo->id)); ?>" class="btn-premium secondary" style="padding: 0.2rem 0.5rem; min-height: 30px; width: auto;"><i class="fa-solid fa-pen"></i></a>
                    <form action="<?php echo e(route('insumos.destroy', $insumo->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn-premium" style="background: #ef4444; padding: 0.2rem 0.5rem; min-height: 30px; width: auto;" onclick="return confirm('¿Eliminar?')"><i class="fa-solid fa-trash"></i></button>
                    </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/kusimikuy-characato/resources/views/insumos/index.blade.php ENDPATH**/ ?>