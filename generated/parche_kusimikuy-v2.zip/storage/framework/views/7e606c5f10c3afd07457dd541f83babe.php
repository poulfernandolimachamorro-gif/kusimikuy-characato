<?php $__env->startSection('title', 'Nuevo Gasto'); ?>

<?php $__env->startSection('content'); ?>
<div class="caja-cristal" style="max-width: 600px; margin: 0 auto; padding: 2rem;">
    <h2 style="color: white; margin-bottom: 1.5rem;">Registrar Gasto</h2>
    
    <?php if($errors->any()): ?>
        <div style="background: rgba(239, 68, 68, 0.1); border-left: 4px solid #ef4444; color: #fca5a5; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem;">
            <ul style="margin: 0; padding-left: 1.5rem;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('gastos.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        
        <div style="margin-bottom: 1rem;">
            <label style="color: #cbd5e1; display: block; margin-bottom: 0.5rem;">Concepto del Gasto:</label>
            <input type="text" name="concepto" class="input-asistencia-premium" required placeholder="Ej: Compra de papas y carne">
        </div>

        <div style="margin-bottom: 1rem;">
            <label style="color: #cbd5e1; display: block; margin-bottom: 0.5rem;">Monto (S/.):</label>
            <input type="number" step="0.01" name="monto" class="input-asistencia-premium" required placeholder="50.00">
        </div>

        <div style="margin-bottom: 1.5rem;">
            <label style="color: #cbd5e1; display: block; margin-bottom: 0.5rem;">Fecha del Gasto:</label>
            <input type="date" name="fecha_gasto" class="input-asistencia-premium" required value="<?php echo e(date('Y-m-d')); ?>">
        </div>

        <button type="submit" class="btn-premium" style="width: 100%;">Guardar Gasto</button>
        <a href="<?php echo e(route('gastos.index')); ?>" class="btn-premium secondary" style="width: 100%; margin-top: 0.5rem; text-align: center;">Cancelar</a>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/kusimikuy-characato/resources/views/gastos/create.blade.php ENDPATH**/ ?>