<?php $__env->startSection('title', 'Asistencia Diaria'); ?>

<?php $__env->startSection('content'); ?>
<!-- Estilos propios del módulo: animaciones y efecto de cristal -->
<style>
    @keyframes moduloSlideIn {
        from { opacity: 0; transform: translateY(15px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .contenedor-animado {
        animation: moduloSlideIn 0.40s cubic-bezier(0.16, 1, 0.3, 1) both;
    }

    /* Tarjeta con efecto de cristal (glassmorphism) */
    .caja-cristal {
        background: rgba(18, 24, 38, 0.65) !important;
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        border: 1px solid rgba(255, 255, 255, 0.05) !important;
        border-radius: 14px !important;
        padding: 1.75rem;
        margin-bottom: 1.5rem;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .caja-cristal:hover {
        box-shadow: 0 10px 40px rgba(26, 117, 255, 0.08);
    }

    /* Diseño adaptable: columnas en pantallas grandes, apiladas en móviles */
    .flex-asistencia {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
        width: 100%;
    }
    @media (min-width: 992px) {
        .flex-asistencia {
            flex-direction: row !important;
        }
        .col-formulario { flex: 1.2; }
        .col-restriccion { flex: 0.8; }
    }

    .input-asistencia-premium {
        background-color: #0f1422 !important;
        border: 1px solid rgba(255, 255, 255, 0.08) !important;
        color: #ffffff !important;
        border-radius: 8px !important;
        padding: 0.75rem 1rem !important;
        font-size: 0.95rem !important;
        margin-bottom: 0 !important;
        width: 100%;
        transition: all 0.3s ease;
    }
    
    .input-asistencia-premium:focus {
        border-color: #1a75ff !important;
        box-shadow: 0 0 12px rgba(26, 117, 255, 0.2) !important;
        outline: none;
    }

    .tarjeta-radio-social {
        background: rgba(255, 255, 255, 0.01);
        border: 1px solid rgba(255, 255, 255, 0.04);
        padding: 0.85rem 1rem;
        border-radius: 8px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 0.75rem;
        user-select: none;
        margin-bottom: 0.75rem;
        transition: all 0.2s ease;
    }
    
    .tarjeta-radio-social:hover {
        background: rgba(26, 117, 255, 0.03);
        border-color: rgba(26, 117, 255, 0.15);
        transform: translateX(3px);
    }

    progress.barra-progreso-neon {
        height: 10px;
        border-radius: 10px;
        background-color: #161f30 !important;
        border: none;
        width: 100%;
        display: block;
        margin-top: 0.5rem;
    }
    
    progress.barra-progreso-neon::-webkit-progress-value {
        background: linear-gradient(90deg, #eab308, #f59e0b) !important;
        border-radius: 10px;
        animation: pulseBar 2s infinite alternate;
    }

    @keyframes pulseBar {
        from { opacity: 0.8; }
        to { opacity: 1; }
    }

    /* Estilos de las alertas de error y éxito */
    .alerta-error {
        background: rgba(239, 68, 68, 0.1);
        border-left: 4px solid #ef4444;
        color: #fca5a5;
        padding: 1rem;
        border-radius: 8px;
        margin-bottom: 1.5rem;
        animation: moduloSlideIn 0.4s ease-out;
    }

    .alerta-exito {
        background: rgba(34, 197, 94, 0.1);
        border-left: 4px solid #22c55e;
        color: #86efac;
        padding: 1rem;
        border-radius: 8px;
        margin-bottom: 1.5rem;
        animation: moduloSlideIn 0.4s ease-out;
    }
</style>

<div class="contenedor-animado">
    <!-- Barra superior: botón de volver, título y fecha actual -->
    <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem; margin-bottom: 2rem; padding-bottom: 0.75rem; border-bottom: 1px solid rgba(255, 255, 255, 0.04);">
        <div style="display: flex; align-items: center; gap: 0.75rem;">
            <a href="<?php echo e(route('dashboard')); ?>" class="btn-premium secondary" style="width: auto; padding: 0 1rem;">
                <i class="fa-solid fa-arrow-left"></i> Volver
            </a>
            <h3 style="margin: 0; font-size: 1.5rem; font-weight: 800; color: #ffffff; letter-spacing: -0.01em;">Control de Asistencia y Marcado</h3>
        </div>
        <div class="subtexto" style="font-weight: 600; background: rgba(255,255,255,0.02); padding: 0.4rem 0.8rem; border-radius: 6px; border: 1px solid rgba(255,255,255,0.04);">
            <i class="fa-solid fa-calendar text-exito"></i> Fecha: <?php echo e(date('d/m/Y')); ?>

        </div>
    </div>

    <!-- Mensajes de éxito y errores de validación -->
    <?php if(session('success')): ?>
        <div class="alerta-exito">
            <i class="fa-solid fa-circle-check"></i> <strong>¡Operación Exitosa!</strong><br>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alerta-error">
            <i class="fa-solid fa-triangle-exclamation"></i> <strong>Se encontraron los siguientes errores:</strong>
            <ul style="margin-top: 0.5rem; margin-bottom: 0; padding-left: 1.5rem; list-style-type: disc;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Contenedor de las dos columnas -->
    <div class="flex-asistencia">
        
        <!-- Columna izquierda: formulario de registro de asistencia -->
        <div class="col-formulario">
            <div class="caja-cristal">
                <h4 style="margin: 0 0 1.25rem 0; font-size: 1.1rem; display: flex; align-items: center; gap: 0.5rem; color: #ffffff; border-bottom: 1px solid rgba(255,255,255,0.04); padding-bottom: 0.5rem;">
                    <i class="fa-solid fa-cash-register" style="color: #1a75ff;"></i> Liquidación de Raciones de Padrón
                </h4>
                
                <!-- Formulario: envía los datos a la ruta asistencia.store -->
                <form action="<?php echo e(route('asistencia.store')); ?>" method="POST" id="form-asistencia">
                    <?php echo csrf_field(); ?>
                    
                    <!-- Código del comensal (anonimizado, según la Ley 29733) -->
                    <div style="margin-bottom: 1.25rem;">
                        <label for="codigo_beneficiario" style="font-weight: 600; margin-bottom: 0.4rem; display: block; font-size: 0.9rem; color: #cbd5e1;">
                            Código Identificador del Comensal (80 Base):
                        </label>
                        <div style="display: flex; gap: 0.5rem;">
                            <!-- Conserva el valor escrito si la validación falla -->
                            <input type="text" id="codigo_beneficiario" name="codigo_beneficiario" class="input-asistencia-premium" placeholder="Ej: BEN-CHA-024" value="<?php echo e(old('codigo_beneficiario')); ?>" required style="flex-grow: 1;">
                            <button type="button" class="btn-premium" style="min-height: auto; width: 50px; padding: 0; border-radius: 8px !important;" title="Escanear Huella (Próximamente)">
                                <i class="fa-solid fa-fingerprint"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Categoría del comensal y cuota aplicada (RF-03) -->
                    <div style="margin-bottom: 1.25rem;">
                        <span style="font-weight: 600; font-size: 0.9rem; color: #cbd5e1; display: block; margin-bottom: 0.5rem;">Categoría para Aplicación de Cuota:</span>
                        
                        <label class="tarjeta-radio-social" for="socia">
                            <input type="radio" id="socia" name="tipo_comensal" value="Socio/Cocinera" <?php echo e(old('tipo_comensal') == 'Socio/Cocinera' ? 'checked' : ''); ?> checked style="margin: 0; width: 16px; height: 16px; cursor: pointer;">
                            <div>
                                <strong style="color: #ffffff; font-size: 0.9rem; display: block;">Socia / Madre de Cocina Voluntaria</strong>
                                <span style="font-size: 0.8rem;" class="text-exito">Cuota social: S/. 5.00 por ración</span>
                            </div>
                        </label>

                        <label class="tarjeta-radio-social" for="publico">
                            <input type="radio" id="publico" name="tipo_comensal" value="Público General" <?php echo e(old('tipo_comensal') == 'Público General' ? 'checked' : ''); ?> style="margin: 0; width: 16px; height: 16px; cursor: pointer;">
                            <div>
                                <strong style="color: #ffffff; font-size: 0.9rem; display: block;">Público General / Vecino Externo</strong>
                                <span style="font-size: 0.8rem; color: #66b2ff;">Cuota estándar: S/. 8.00 por ración</span>
                            </div>
                        </label>
                    </div>

                    <!-- Cantidad de raciones a retirar -->
                    <div style="margin-bottom: 1.25rem;">
                        <label for="raciones_retiradas" style="font-weight: 600; margin-bottom: 0.4rem; display: block; font-size: 0.9rem; color: #cbd5e1;">
                            Cantidad de Almuerzos a Retirar:
                        </label>
                        <input type="number" id="raciones_retiradas" name="raciones_retiradas" class="input-asistencia-premium" min="1" max="4" value="<?php echo e(old('raciones_retiradas', 1)); ?>" required>
                    </div>

                    <!-- Exoneración de cuota -->
                    <div style="margin-bottom: 1.75rem; background: rgba(250, 204, 21, 0.02); padding: 0.75rem 1rem; border-radius: 8px; border: 1px dashed rgba(250, 204, 21, 0.15);">
                        <label for="exonerado" style="display: flex; align-items: center; gap: 0.5rem; margin: 0; cursor: pointer; user-select: none;">
                            <input type="checkbox" id="exonerado" name="exonerado" value="1" <?php echo e(old('exonerado') ? 'checked' : ''); ?> style="margin: 0; width: 15px; height: 15px;">
                            <span style="font-size: 0.85rem; font-weight: 600; color: #facc15;">Exonerar cuota por vulnerabilidad extrema.</span>
                        </label>
                    </div>

                    <!-- Botón de envío (los IDs los usa el script del final) -->
                    <button type="submit" class="btn-premium" id="btn-guardar">
                        <i class="fa-solid fa-check" id="icon-guardar"></i> <span id="texto-guardar">Guardar Asistencia y Procesar Salida</span>
                    </button>
                </form>
            </div>
        </div>

        <!-- Columna derecha: límite diario de arroz (RF-04) -->
        <div class="col-restriccion">
            <div class="caja-cristal" style="border-color: rgba(239, 68, 68, 0.12) !important;">
                <h4 style="color: #f87171; margin: 0 0 1rem 0; font-size: 1.1rem; display: flex; align-items: center; gap: 0.4rem; border-bottom: 1px solid rgba(255,255,255,0.04); padding-bottom: 0.5rem;">
                    <i class="fa-solid fa-scale-balanced"></i> Restricción Municipal MPA
                </h4>
                
                <p class="subtexto" style="line-height: 1.35rem; font-size: 0.85rem; margin: 0 0 1.25rem 0;">
                    Tope estricto fiscalizado por la **Municipalidad Provincial de Arequipa**. Evita observaciones administrativas controlando el consumo diario acumulado de arroz del comedor.
                </p>

                <div style="background: #090d16; padding: 1rem; border-radius: 8px; border: 1px solid rgba(255,255,255,0.02); margin-bottom: 1.25rem;">
                    <div style="display: flex; justify-content: space-between; font-size: 0.8rem; font-weight: 600;">
                        <span style="color: #94a3b8;">Gasto de Arroz Hoy:</span>
                        <span style="color: #facc15;" id="texto-progreso"><?php echo e(number_format($consumoHoy ?? 0, 2)); ?> kg / 6.00 kg</span>
                    </div>
                    <progress value="<?php echo e($consumoHoy ?? 0); ?>" max="6.00" class="barra-progreso-neon" id="barra-arroz"></progress>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Script: muestra un spinner al enviar el formulario -->
<script>
    document.getElementById('form-asistencia').addEventListener('submit', function(e) {
        // Al enviar, se obtienen los elementos del botón para modificarlos
        const btn = document.getElementById('btn-guardar');
        const icon = document.getElementById('icon-guardar');
        const texto = document.getElementById('texto-guardar');

        // Se desactiva el botón para evitar envíos duplicados
        btn.disabled = true;
        btn.style.opacity = '0.7';
        btn.style.cursor = 'not-allowed';

        // Se reemplaza el ícono por un spinner y se cambia el texto
        icon.className = 'fa-solid fa-spinner fa-spin';
        texto.innerText = 'Procesando transacción...';
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/kusimikuy-characato/resources/views/asistencia/index.blade.php ENDPATH**/ ?>