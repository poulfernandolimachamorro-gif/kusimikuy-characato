<?php $__env->startSection('title', 'Documentos'); ?>
<?php $__env->startSection('content'); ?>
<div class="caja-cristal" style="padding: 2rem;">
    <div style="display: flex; justify-content: space-between; margin-bottom: 1.5rem;">
        <h2 style="color: white;">Documentos Legales</h2>
        <a href="<?php echo e(route('documentos.create')); ?>" class="btn-premium" style="width: auto;">+ Nuevo Documento</a>
    </div>
    <?php if(session('success')): ?> <div class="alerta-exito"><?php echo e(session('success')); ?></div> <?php endif; ?>
    <?php if($errors->any()): ?>
        <div style="background: rgba(239, 68, 68, 0.1); border-left: 4px solid #ef4444; color: #fca5a5; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem;">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <div><?php echo e($error); ?></div> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    <table style="width: 100%; color: #cbd5e1;">
        <thead><tr style="border-bottom: 1px solid #333;"><th>Tipo</th><th>Emisión</th><th>Caducidad</th><th>Vigencia</th><th>Acciones</th></tr></thead>
        <tbody>
            <?php $__currentLoopData = $documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="border-bottom: 1px solid #222;">
                <td><?php echo e($doc->tipo_documento); ?></td>
                <td><?php echo e($doc->fecha_emision); ?></td>
                <td><?php echo e($doc->fecha_caducidad); ?></td>
                <td>
                    <span style="color: <?php echo e($doc->color_vigencia); ?>; font-weight: 700;"><?php echo e($doc->estado_vigencia); ?></span>
                    <span style="font-size: 0.8rem; color: #94a3b8;">
                        <?php if($doc->dias_restantes >= 0): ?> (<?php echo e($doc->dias_restantes); ?> días) <?php else: ?> <?php endif; ?>
                    </span>
                </td>
                <td>
                    <form action="<?php echo e(route('documentos.destroy', $doc->id)); ?>" method="POST"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn-premium" style="background:#ef4444; width:auto; min-height:30px; padding:0 0.5rem;" onclick="return confirm('¿Eliminar?')"><i class="fa-solid fa-trash"></i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/kusimikuy-characato/resources/views/documentos/index.blade.php ENDPATH**/ ?>