<?php $__env->startSection('title', 'Editar Insumo'); ?>
<?php $__env->startSection('content'); ?>
<div class="caja-cristal" style="max-width: 600px; margin: 0 auto; padding: 2rem;">
    <h2 style="color: white; margin-bottom: 1.5rem;">Modificar Parámetros de Insumo</h2>
    <form action="<?php echo e(route('insumos.update', $insumo->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div style="margin-bottom: 1rem;">
            <label style="color: #cbd5e1; display: block; margin-bottom: 0.5rem;">Nombre del Insumo:</label>
            <input type="text" name="nombre_insumo" class="input-asistencia-premium" value="<?php echo e($insumo->nombre_insumo); ?>" required>
        </div>
        
        <div style="margin-bottom: 1rem;">
            <label style="color: #cbd5e1; display: block; margin-top: 1rem; margin-bottom: 0.5rem;">Masa/Volumen Físico Actual:</label>
            <input type="number" step="0.01" name="stock_actual" class="input-asistencia-premium" value="<?php echo e($insumo->stock_actual); ?>" required>
        </div>

        <div style="margin-bottom: 1.5rem;">
            <label style="color: #cbd5e1; display: block; margin-top: 1rem; margin-bottom: 0.5rem;">Unidad Estandarizada:</label>
            <select name="unidad_medida" class="input-asistencia-premium">
                <option value="Kilogramos" <?php echo e($insumo->unidad_medida == 'Kilogramos' ? 'selected' : ''); ?>>Kilogramos</option>
                <option value="Litros" <?php echo e($insumo->unidad_medida == 'Litros' ? 'selected' : ''); ?>>Litros</option>
                <option value="Unidades" <?php echo e($insumo->unidad_medida == 'Unidades' ? 'selected' : ''); ?>>Unidades</option>
                <option value="Sacos" <?php echo e($insumo->unidad_medida == 'Sacos' ? 'selected' : ''); ?>>Sacos</option>
            </select>
        </div>
        <button type="submit" class="btn-premium" style="width: 100%;">Actualizar Existencias</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/kusimikuy-characato/resources/views/insumos/edit.blade.php ENDPATH**/ ?>