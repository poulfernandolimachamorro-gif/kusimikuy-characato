<?php $__env->startSection('title', 'Nuevo Insumo'); ?>
<?php $__env->startSection('content'); ?>
<div class="caja-cristal" style="max-width: 600px; margin: 0 auto;">
    <h2 style="color: white;">Registrar Insumo</h2>
    <form action="<?php echo e(route('insumos.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label style="color: #cbd5e1;">Nombre del Insumo:</label>
        <input type="text" name="nombre_insumo" class="input-asistencia-premium" required>
        
        <label style="color: #cbd5e1; margin-top: 1rem; display: block;">Stock Inicial:</label>
        <input type="number" step="0.01" name="stock_actual" class="input-asistencia-premium" required>

        <label style="color: #cbd5e1; margin-top: 1rem; display: block;">Unidad de Medida:</label>
        <select name="unidad_medida" class="input-asistencia-premium">
            <option value="Kilogramos">Kilogramos</option>
            <option value="Litros">Litros</option>
            <option value="Unidades">Unidades</option>
            <option value="Sacos">Sacos</option>
        </select>
        <button type="submit" class="btn-premium" style="margin-top: 1.5rem;">Guardar Insumo</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/kusimikuy-characato/resources/views/insumos/create.blade.php ENDPATH**/ ?>