<?php $__env->startSection('title', 'Gastos'); ?>

<?php $__env->startSection('content'); ?>
<div class="caja-cristal" style="padding: 2rem;">
    <div style="display: flex; justify-content: space-between; margin-bottom: 1.5rem; align-items: center;">
        <h2 style="color: white; margin: 0;">Registro de Gastos</h2>
        <a href="<?php echo e(route('gastos.create')); ?>" class="btn-premium" style="width: auto;">+ Nuevo Gasto</a>
    </div>
    
    <?php if(session('success')): ?>
        <div class="alerta-exito" style="background: rgba(34, 197, 94, 0.1); border-left: 4px solid #22c55e; color: #86efac; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem;">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table style="width: 100%; border-collapse: collapse; color: #cbd5e1;">
        <thead>
            <tr style="border-bottom: 2px solid rgba(255,255,255,0.1); text-align: left;">
                <th style="padding: 1rem;">Concepto</th>
                <th style="padding: 1rem;">Monto</th>
                <th style="padding: 1rem;">Fecha</th>
                <th style="padding: 1rem;">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $gastos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                <td style="padding: 1rem;"><?php echo e($gasto->concepto); ?></td>
                <td style="padding: 1rem; font-weight: bold; color: #f87171;">S/. <?php echo e(number_format($gasto->monto, 2)); ?></td>
                <td style="padding: 1rem;"><?php echo e($gasto->fecha_gasto); ?></td>
                <td style="padding: 1rem;">
                    <a href="<?php echo e(route('gastos.edit', $gasto->id)); ?>" class="btn-premium secondary" style="padding: 0.2rem 0.5rem; min-height: 30px; width: auto; display: inline-flex;"><i class="fa-solid fa-pen"></i></a>
                    <form action="<?php echo e(route('gastos.destroy', $gasto->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?> 
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn-premium" style="background:#ef4444; width:auto; min-height:30px; padding:0 0.5rem;" onclick="return confirm('¿Eliminar este gasto?')">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($gastos->isEmpty()): ?>
            <tr>
                <td colspan="4" style="text-align: center; padding: 2rem; color: #94a3b8;">No hay gastos registrados.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/kusimikuy-characato/resources/views/gastos/index.blade.php ENDPATH**/ ?>