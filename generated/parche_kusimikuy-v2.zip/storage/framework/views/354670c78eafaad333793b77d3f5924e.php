<?php $__env->startSection('title', 'Padrón de Beneficiarios'); ?>

<?php $__env->startSection('content'); ?>
<div class="animacion-entrada">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <h2 style="color: white; font-weight: 800; margin: 0;">
            <i class="fa-solid fa-users text-exito"></i> Padrón Oficial de Comensales
        </h2>
        <a href="<?php echo e(route('dashboard')); ?>" class="btn-premium secondary" style="width: auto; min-height: 40px; padding: 0 1rem;">
            <i class="fa-solid fa-arrow-left"></i> Volver
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alerta-exito" style="background: rgba(34, 197, 94, 0.1); border-left: 4px solid #22c55e; color: #86efac; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem;">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="caja-cristal">
        <div style="margin-bottom: 1rem;">
            <a href="<?php echo e(route('beneficiarios.create')); ?>" class="btn-premium" style="width: auto;">+ Nuevo Beneficiario</a>
        </div>
        <table style="width: 100%; border-collapse: collapse; color: #cbd5e1;">
            <thead>
                <tr style="border-bottom: 2px solid rgba(255,255,255,0.1); text-align: left;">
                    <th style="padding: 1rem;">Código Anonimizado</th>
                    <th style="padding: 1rem;">Tipo de Comensal</th>
                    <th style="padding: 1rem;">Integrantes</th>
                    <th style="padding: 1rem;">Raciones</th>
                    <th style="padding: 1rem;">Estado</th>
                    <th style="padding: 1rem;">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $beneficiarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beneficiario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                    <td style="padding: 1rem; font-weight: bold; color: #66b2ff;"><?php echo e($beneficiario->codigo_beneficiario); ?></td>
                    <td style="padding: 1rem;"><?php echo e($beneficiario->tipo_comensal); ?></td>
                    <td style="padding: 1rem;"><?php echo e($beneficiario->cantidad_integrantes); ?> personas</td>
                    <td style="padding: 1rem;"><?php echo e($beneficiario->raciones_asignadas); ?> platos</td>
                    <td style="padding: 1rem;">
                        <span style="background: rgba(34, 197, 94, 0.1); color: #4ade80; padding: 0.2rem 0.6rem; border-radius: 4px; font-size: 0.8rem; font-weight: bold;">
                            Activo
                        </span>
                    </td>
                    <td style="padding: 1rem; display: flex; gap: 0.5rem;">
                        <!-- Botón Editar Funcional -->
                        <a href="<?php echo e(route('beneficiarios.edit', $beneficiario->id)); ?>" class="btn-premium secondary" style="padding: 0.2rem 0.5rem; min-height: 30px; width: auto;">
                            <i class="fa-solid fa-pen"></i>
                        </a>
                        <!-- Botón Eliminar Funcional -->
                        <form action="<?php echo e(route('beneficiarios.destroy', $beneficiario->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn-premium" style="background: #ef4444 !important; padding: 0.2rem 0.5rem; min-height: 30px; width: auto;" onclick="return confirm('¿Dar de baja lógica a este beneficiario?')">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/kusimikuy-characato/resources/views/beneficiarios/index.blade.php ENDPATH**/ ?>